
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

typedef
    unsigned char
uchar;

int main(int argc, char *argv[])
{
    int x;

    x = rmdir("./stuff");
    printf("x=%d\n",x);
}


