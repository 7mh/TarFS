#!/usr/bin/env python3

import sys
from matplotlib import pyplot as plt


if __name__ == "__main__":


    print("Hello, world.")
    pass

